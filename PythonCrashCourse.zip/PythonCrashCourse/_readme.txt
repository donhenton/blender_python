Thank you for the support! :)

Remember to provide credit when sharing derivative work.

---
Website:
www.curtisholt.online
---
Stores:
https://gumroad.com/curtisjamesholt
https://blendermarket.com/creators/curtis-holt
---
Social Links:
www.youtube.com/CurtisHolt
www.twitter.com/curtisjamesholt
www.instagram.com/curtisjamesholt/
www.artstation.com/curtisjamesholt
---
Discord Server:
https://discord.gg/aMDpFtc
---